#!/usr/bin/python

fil = 5
while fil >= 1:
   col = 1
   while col <= fil:
      print col,
      col = col + 1
   print
   fil = fil - 1

