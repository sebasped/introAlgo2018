#!/usr/bin/python

fil = 1
while fil <= 5:
   col = 1
   while col <= fil:
      print col,
      col = col + 1
   print
   fil = fil + 1

